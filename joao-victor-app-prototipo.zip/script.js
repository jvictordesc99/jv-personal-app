const titles = {
  home: "Painel inicial",
  treino: "Treino",
  videos: "Videos dos exercicios",
  avaliacao: "Avaliacao fisica",
  evolucao: "Evolucao corporal",
  agenda: "Agenda das aulas",
  beach: "Area beach tennis",
  admin: "Area administrativa",
};

const navButtons = document.querySelectorAll(".nav-item");
const views = document.querySelectorAll(".view");
const pageTitle = document.querySelector("#page-title");

function openView(id) {
  navButtons.forEach((button) => button.classList.toggle("active", button.dataset.view === id));
  views.forEach((view) => view.classList.toggle("active", view.id === id));
  pageTitle.textContent = titles[id] || "Painel inicial";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

navButtons.forEach((button) => {
  button.addEventListener("click", () => openView(button.dataset.view));
});

document.querySelectorAll("[data-jump]").forEach((button) => {
  button.addEventListener("click", () => openView(button.dataset.jump));
});

const studentStorageKey = "joao-victor-students";
const workoutStorageKey = "joao-victor-workouts";
const defaultStudents = [
  { name: "Marina Costa", plan: "Performance", value: "R$ 250,00", due: "05/06", payment: "Em dia" },
  { name: "Pedro Alves", plan: "Beach", value: "R$ 180,00", due: "10/06", payment: "Pendente" },
  { name: "Ana Lima", plan: "Completo", value: "R$ 320,00", due: "15/06", payment: "Em dia" },
];

const studentForm = document.querySelector("#student-form");
const studentList = document.querySelector("#student-list");
const studentCount = document.querySelector("#student-count");
const pendingCount = document.querySelector("#pending-count");
const nameInput = document.querySelector("#student-name");
const planInput = document.querySelector("#student-plan");
const valueInput = document.querySelector("#student-value");
const dueInput = document.querySelector("#student-due");
const paymentInput = document.querySelector("#student-payment");
const newStudentButton = document.querySelector("[data-focus-student]");
const saveMessage = document.querySelector("#save-message");
const saveStudentButton = document.querySelector("#save-student-button");
const cancelEditButton = document.querySelector("#cancel-edit-button");
const workoutForm = document.querySelector("#workout-form");
const workoutStudent = document.querySelector("#workout-student");
const workoutViewStudent = document.querySelector("#workout-view-student");
const workoutTitle = document.querySelector("#workout-title");
const workoutExercises = document.querySelector("#workout-exercises");
const addExerciseButton = document.querySelector("#add-exercise-button");
const workoutTemplateSource = document.querySelector("#workout-template-source");
const loadWorkoutButton = document.querySelector("#load-workout-button");
const workoutMessage = document.querySelector("#workout-message");
const workoutList = document.querySelector("#workout-list");
const currentWorkout = document.querySelector("#current-workout");
const workoutTabs = document.querySelector("#workout-tabs");
const saveWorkoutButton = document.querySelector("#save-workout-button");
const cancelWorkoutEditButton = document.querySelector("#cancel-workout-edit-button");
let memoryStudents = null;
let memoryWorkouts = null;
let editingStudentIndex = null;
let editingWorkout = null;
const activeWorkoutByStudent = {};

function showMessage(text, type = "success") {
  saveMessage.textContent = text;
  saveMessage.classList.toggle("error", type === "error");
}

function loadStudents() {
  if (memoryStudents) return memoryStudents;

  try {
    const savedStudents = localStorage.getItem(studentStorageKey);
    memoryStudents = savedStudents ? JSON.parse(savedStudents) : [...defaultStudents];
  } catch {
    memoryStudents = [...defaultStudents];
    showMessage("O navegador bloqueou o salvamento local neste modo de arquivo.", "error");
  }

  return memoryStudents;
}

function saveStudents(students) {
  memoryStudents = students;

  try {
    localStorage.setItem(studentStorageKey, JSON.stringify(students));
    showMessage("Aluno salvo neste navegador.");
  } catch {
    showMessage("Aluno apareceu na lista, mas este navegador bloqueou salvar ao recarregar.", "error");
  }
}

function loadWorkouts() {
  if (memoryWorkouts) return memoryWorkouts;

  try {
    const savedWorkouts = localStorage.getItem(workoutStorageKey);
    memoryWorkouts = normalizeWorkoutsData(savedWorkouts ? JSON.parse(savedWorkouts) : {});
  } catch {
    memoryWorkouts = {};
  }

  return memoryWorkouts;
}

function saveWorkouts(workouts) {
  memoryWorkouts = workouts;

  try {
    localStorage.setItem(workoutStorageKey, JSON.stringify(workouts));
    workoutMessage.textContent = "Treino salvo para o aluno.";
    workoutMessage.classList.remove("error");
  } catch {
    workoutMessage.textContent = "Treino apareceu na lista, mas este navegador bloqueou salvar ao recarregar.";
    workoutMessage.classList.add("error");
  }
}

function createId() {
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function normalizeWorkout(workout) {
  return {
    id: workout.id || createId(),
    title: workout.title || "Treino",
    exercises: (workout.exercises || []).map(normalizeExercise),
  };
}

function normalizeWorkoutsData(workouts) {
  return Object.fromEntries(
    Object.entries(workouts).map(([studentName, studentWorkouts]) => {
      if (Array.isArray(studentWorkouts)) {
        return [studentName, studentWorkouts.map(normalizeWorkout)];
      }

      return [studentName, [normalizeWorkout(studentWorkouts)]];
    }),
  );
}

function fillStudentSelects() {
  const students = loadStudents();
  const selectedWorkoutStudent = workoutStudent.value;
  const selectedViewStudent = workoutViewStudent.value;

  workoutStudent.replaceChildren();
  workoutViewStudent.replaceChildren();

  students.forEach((student) => {
    const adminOption = document.createElement("option");
    adminOption.textContent = student.name;
    adminOption.value = student.name;

    const viewOption = document.createElement("option");
    viewOption.textContent = student.name;
    viewOption.value = student.name;

    workoutStudent.appendChild(adminOption);
    workoutViewStudent.appendChild(viewOption);
  });

  workoutStudent.value = selectedWorkoutStudent || students[0]?.name || "";
  workoutViewStudent.value = selectedViewStudent || students[0]?.name || "";
}

function createStudentRow(student, index) {
  const row = document.createElement("div");
  row.className = "table-row student-row";

  const name = document.createElement("span");
  name.textContent = student.name;

  const plan = document.createElement("span");
  plan.textContent = student.plan;

  const value = document.createElement("span");
  value.textContent = student.value;
  const due = document.createElement("small");
  due.textContent = `Vence ${student.due}`;
  value.appendChild(due);

  const status = document.createElement("span");
  status.textContent = "Ativo";

  const payment = document.createElement("span");
  payment.className = student.payment === "Pendente" ? "status-pending" : "status-ok";
  payment.textContent = student.payment;

  const remove = document.createElement("button");
  remove.type = "button";
  remove.dataset.removeStudent = index;
  remove.textContent = "Remover";

  const actions = document.createElement("span");
  actions.className = "student-actions";

  const edit = document.createElement("button");
  edit.type = "button";
  edit.dataset.editStudent = index;
  edit.textContent = "Editar";

  actions.append(edit, remove);
  row.append(name, plan, value, status, payment, actions);
  return row;
}

function renderStudents() {
  const students = loadStudents();
  const pendingStudents = students.filter((student) => student.payment === "Pendente");

  studentList.innerHTML = "";
  students.forEach((student, index) => {
    studentList.appendChild(createStudentRow(student, index));
  });

  studentCount.textContent = students.length;
  pendingCount.textContent = pendingStudents.length;
  fillStudentSelects();
  renderWorkouts();
}

function createWorkoutRow(studentName, workout) {
  const row = document.createElement("div");
  row.className = "table-row workout-row";

  const student = document.createElement("span");
  student.textContent = studentName;

  const title = document.createElement("span");
  title.textContent = workout.title;

  const total = document.createElement("span");
  total.textContent = `${workout.exercises.length} exercicios`;

  const actions = document.createElement("span");
  actions.className = "student-actions";

  const edit = document.createElement("button");
  edit.type = "button";
  edit.dataset.editWorkoutStudent = studentName;
  edit.dataset.editWorkoutId = workout.id;
  edit.textContent = "Editar";

  const copy = document.createElement("button");
  copy.type = "button";
  copy.dataset.copyWorkoutStudent = studentName;
  copy.dataset.copyWorkoutId = workout.id;
  copy.textContent = "Usar";

  const remove = document.createElement("button");
  remove.type = "button";
  remove.dataset.removeWorkoutStudent = studentName;
  remove.dataset.removeWorkoutId = workout.id;
  remove.textContent = "Remover";

  actions.append(edit, copy, remove);
  row.append(student, title, total, actions);
  return row;
}

function normalizeExercise(exercise) {
  if (typeof exercise === "string") {
    return { name: exercise, weight: "", reps: "", sets: "", rest: "" };
  }

  return {
    name: exercise.name || "",
    weight: exercise.weight || "",
    reps: exercise.reps || "",
    sets: exercise.sets || "",
    rest: exercise.rest || "",
  };
}

function createExerciseFormRow(exercise = {}) {
  const row = document.createElement("div");
  row.className = "exercise-form-row";

  const fields = [
    ["name", "Nome do exercicio", true],
    ["weight", "Ex: 20 kg", false],
    ["reps", "Ex: 12", false],
    ["sets", "Ex: 4", false],
    ["rest", "Ex: 60s", false],
  ];

  fields.forEach(([key, placeholder, required]) => {
    const input = document.createElement("input");
    input.dataset.exerciseField = key;
    input.placeholder = placeholder;
    input.value = exercise[key] || "";
    if (required) input.required = true;
    row.appendChild(input);
  });

  const remove = document.createElement("button");
  remove.type = "button";
  remove.className = "secondary";
  remove.dataset.removeExerciseRow = "true";
  remove.textContent = "Remover";
  row.appendChild(remove);

  return row;
}

function addExerciseRow(exercise = {}) {
  workoutExercises.appendChild(createExerciseFormRow(exercise));
}

function resetExerciseRows(exercises = [{}]) {
  workoutExercises.replaceChildren();
  exercises.map(normalizeExercise).forEach(addExerciseRow);
}

function getWorkoutCopy(studentName, workoutId) {
  const workout = (loadWorkouts()[studentName] || []).find((item) => item.id === workoutId);
  if (!workout) return null;

  return {
    title: workout.title,
    exercises: workout.exercises.map(normalizeExercise),
  };
}

function loadWorkoutIntoForm(sourceStudent, workoutId) {
  const workout = getWorkoutCopy(sourceStudent, workoutId);
  if (!workout) return;

  workoutTitle.value = workout.title;
  resetExerciseRows(workout.exercises);
  editingWorkout = null;
  saveWorkoutButton.textContent = "Salvar treino";
  cancelWorkoutEditButton.hidden = true;
  workoutMessage.textContent = "Ficha carregada. Escolha o aluno destino e salve.";
  workoutMessage.classList.remove("error");
}

function collectExerciseRows() {
  return [...workoutExercises.querySelectorAll(".exercise-form-row")]
    .map((row) => ({
      name: row.querySelector('[data-exercise-field="name"]').value.trim(),
      weight: row.querySelector('[data-exercise-field="weight"]').value.trim(),
      reps: row.querySelector('[data-exercise-field="reps"]').value.trim(),
      sets: row.querySelector('[data-exercise-field="sets"]').value.trim(),
      rest: row.querySelector('[data-exercise-field="rest"]').value.trim(),
    }))
    .filter((exercise) => exercise.name);
}

function renderCurrentWorkout() {
  const workouts = loadWorkouts();
  const selectedStudent = workoutViewStudent.value;
  const studentWorkouts = workouts[selectedStudent] || [];
  const activeWorkoutId = activeWorkoutByStudent[selectedStudent] || studentWorkouts[0]?.id;
  const workout = studentWorkouts.find((item) => item.id === activeWorkoutId) || studentWorkouts[0];

  currentWorkout.innerHTML = "";
  workoutTabs.innerHTML = "";

  if (!selectedStudent) {
    currentWorkout.textContent = "Cadastre um aluno para visualizar treinos.";
    return;
  }

  if (!studentWorkouts.length) {
    currentWorkout.textContent = "Nenhuma ficha salva para este aluno ainda.";
    return;
  }

  activeWorkoutByStudent[selectedStudent] = workout.id;

  studentWorkouts.forEach((studentWorkout) => {
    const tab = document.createElement("button");
    tab.type = "button";
    tab.dataset.workoutTab = studentWorkout.id;
    tab.className = studentWorkout.id === workout.id ? "active" : "";
    tab.textContent = studentWorkout.title;
    workoutTabs.appendChild(tab);
  });

  const title = document.createElement("h3");
  title.textContent = workout.title;
  const list = document.createElement("div");
  list.className = "exercise-display-grid";

  const header = document.createElement("div");
  header.className = "exercise-display-row exercise-display-head";
  ["Exercicio", "Peso", "Repeticoes", "Series", "Descanso"].forEach((label) => {
    const cell = document.createElement("span");
    cell.textContent = label;
    header.appendChild(cell);
  });
  list.appendChild(header);

  workout.exercises.forEach((exercise) => {
    const normalizedExercise = normalizeExercise(exercise);
    const row = document.createElement("div");
    row.className = "exercise-display-row";

    ["name", "weight", "reps", "sets", "rest"].forEach((key) => {
      const cell = document.createElement("span");
      cell.textContent = normalizedExercise[key] || "-";
      row.appendChild(cell);
    });

    list.appendChild(row);
  });

  currentWorkout.append(title, list);
}

function renderWorkouts() {
  const workouts = loadWorkouts();
  workoutList.innerHTML = "";

  Object.entries(workouts).forEach(([studentName, studentWorkouts]) => {
    studentWorkouts.forEach((workout) => {
      workoutList.appendChild(createWorkoutRow(studentName, workout));
    });
  });

  fillWorkoutTemplateSelect();
  renderCurrentWorkout();
}

function fillWorkoutTemplateSelect() {
  const selectedTemplate = workoutTemplateSource.value;
  const workouts = loadWorkouts();
  const templateOptions = Object.entries(workouts).flatMap(([studentName, studentWorkouts]) =>
    studentWorkouts.map((workout) => ({ studentName, workout })),
  );

  workoutTemplateSource.replaceChildren();

  if (!templateOptions.length) {
    const option = document.createElement("option");
    option.textContent = "Nenhuma ficha salva";
    option.value = "";
    workoutTemplateSource.appendChild(option);
    loadWorkoutButton.disabled = true;
    return;
  }

  templateOptions.forEach(({ studentName, workout }) => {
    const option = document.createElement("option");
    option.textContent = `${studentName} - ${workout.title}`;
    option.value = `${studentName}|||${workout.id}`;
    workoutTemplateSource.appendChild(option);
  });

  const fallbackTemplate = `${templateOptions[0].studentName}|||${templateOptions[0].workout.id}`;
  const availableTemplates = templateOptions.map(({ studentName, workout }) => `${studentName}|||${workout.id}`);
  workoutTemplateSource.value = availableTemplates.includes(selectedTemplate) ? selectedTemplate : fallbackTemplate;
  loadWorkoutButton.disabled = false;
}

function resetStudentForm() {
  studentForm.reset();
  paymentInput.value = "Em dia";
  editingStudentIndex = null;
  saveStudentButton.textContent = "Salvar aluno";
  cancelEditButton.hidden = true;
  nameInput.focus();
}

studentForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const students = loadStudents();
  const student = {
    name: nameInput.value.trim(),
    plan: planInput.value.trim(),
    value: valueInput.value.trim(),
    due: dueInput.value.trim(),
    payment: paymentInput.value,
  };

  if (editingStudentIndex === null) {
    students.push(student);
  } else {
    students[editingStudentIndex] = student;
  }

  saveStudents(students);
  renderStudents();
  resetStudentForm();
});

workoutForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const workouts = loadWorkouts();
  const selectedStudent = workoutStudent.value;
  const workout = {
    id: editingWorkout?.id || createId(),
    title: workoutTitle.value.trim(),
    exercises: collectExerciseRows(),
  };

  if (editingWorkout) {
    workouts[editingWorkout.studentName] = (workouts[editingWorkout.studentName] || []).filter(
      (item) => item.id !== editingWorkout.id,
    );
  }

  workouts[selectedStudent] = workouts[selectedStudent] || [];
  workouts[selectedStudent].push(workout);

  saveWorkouts(workouts);
  workoutViewStudent.value = selectedStudent;
  activeWorkoutByStudent[selectedStudent] = workout.id;
  renderWorkouts();
  workoutForm.reset();
  resetExerciseRows();
  editingWorkout = null;
  saveWorkoutButton.textContent = "Salvar treino";
  cancelWorkoutEditButton.hidden = true;
});

workoutViewStudent.addEventListener("change", renderCurrentWorkout);

workoutTabs.addEventListener("click", (event) => {
  const tab = event.target.closest("[data-workout-tab]");
  if (!tab) return;

  activeWorkoutByStudent[workoutViewStudent.value] = tab.dataset.workoutTab;
  renderCurrentWorkout();
});

loadWorkoutButton.addEventListener("click", () => {
  const [studentName, workoutId] = workoutTemplateSource.value.split("|||");
  loadWorkoutIntoForm(studentName, workoutId);
});

workoutList.addEventListener("click", (event) => {
  const editButton = event.target.closest("[data-edit-workout-id]");
  if (editButton) {
    const studentName = editButton.dataset.editWorkoutStudent;
    const workout = (loadWorkouts()[studentName] || []).find((item) => item.id === editButton.dataset.editWorkoutId);

    editingWorkout = { studentName, id: workout.id };
    workoutStudent.value = studentName;
    workoutTitle.value = workout.title;
    resetExerciseRows(workout.exercises);
    saveWorkoutButton.textContent = "Salvar alteracao";
    cancelWorkoutEditButton.hidden = false;
    workoutTitle.focus();
    workoutMessage.textContent = "Editando treino. Altere os campos e salve.";
    workoutMessage.classList.remove("error");
    return;
  }

  const copyButton = event.target.closest("[data-copy-workout-id]");
  if (copyButton) {
    workoutTemplateSource.value = `${copyButton.dataset.copyWorkoutStudent}|||${copyButton.dataset.copyWorkoutId}`;
    loadWorkoutIntoForm(copyButton.dataset.copyWorkoutStudent, copyButton.dataset.copyWorkoutId);
    workoutStudent.focus();
    return;
  }

  const removeButton = event.target.closest("[data-remove-workout-id]");
  if (!removeButton) return;

  const workouts = loadWorkouts();
  const studentName = removeButton.dataset.removeWorkoutStudent;
  workouts[studentName] = (workouts[studentName] || []).filter((workout) => workout.id !== removeButton.dataset.removeWorkoutId);
  if (!workouts[studentName].length) delete workouts[studentName];
  saveWorkouts(workouts);
  renderWorkouts();
});

cancelWorkoutEditButton.addEventListener("click", () => {
  editingWorkout = null;
  workoutForm.reset();
  resetExerciseRows();
  saveWorkoutButton.textContent = "Salvar treino";
  cancelWorkoutEditButton.hidden = true;
  workoutMessage.textContent = "Edicao de treino cancelada.";
  workoutMessage.classList.remove("error");
});

studentList.addEventListener("click", (event) => {
  const editButton = event.target.closest("[data-edit-student]");
  if (editButton) {
    const students = loadStudents();
    const student = students[Number(editButton.dataset.editStudent)];

    editingStudentIndex = Number(editButton.dataset.editStudent);
    nameInput.value = student.name;
    planInput.value = student.plan;
    valueInput.value = student.value;
    dueInput.value = student.due;
    paymentInput.value = student.payment;
    saveStudentButton.textContent = "Salvar alteracao";
    cancelEditButton.hidden = false;
    nameInput.focus();
    showMessage("Editando aluno. Altere os campos e salve.");
    return;
  }

  const removeButton = event.target.closest("[data-remove-student]");
  if (!removeButton) return;

  const students = loadStudents();
  students.splice(Number(removeButton.dataset.removeStudent), 1);
  saveStudents(students);
  renderStudents();
});

cancelEditButton.addEventListener("click", () => {
  resetStudentForm();
  showMessage("Edicao cancelada.");
});

newStudentButton.addEventListener("click", () => {
  openView("admin");
  resetStudentForm();
});

addExerciseButton.addEventListener("click", () => addExerciseRow());

workoutExercises.addEventListener("click", (event) => {
  const removeButton = event.target.closest("[data-remove-exercise-row]");
  if (!removeButton) return;

  const rows = workoutExercises.querySelectorAll(".exercise-form-row");
  if (rows.length === 1) {
    rows[0].querySelectorAll("input").forEach((input) => {
      input.value = "";
    });
    return;
  }

  removeButton.closest(".exercise-form-row").remove();
});

resetExerciseRows();

renderStudents();
